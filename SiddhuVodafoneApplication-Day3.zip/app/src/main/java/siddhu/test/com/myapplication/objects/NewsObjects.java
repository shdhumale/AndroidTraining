package siddhu.test.com.myapplication.objects;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by admin on 8/4/2016.
 */

public class NewsObjects {

    private String imageUrl;
    private String title;
    private String date;
    private String description;
    private String detailsUrl;

    public NewsObjects(String imageUrl, String title, String date, String description, String detailsUrl) {
        this.imageUrl = imageUrl;
        this.title = title;
        this.date = date;
        this.description = description;
        this.detailsUrl = detailsUrl;
    }


    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDetailsUrl() {
        return detailsUrl;
    }

    public void setDetailsUrl(String detailsUrl) {
        this.detailsUrl = detailsUrl;
    }

    private static List<NewsObjects> objNewsObjects = new ArrayList<NewsObjects>();

    public static List<NewsObjects> getObjNewsObjects() {
        return objNewsObjects;
    }

    private static void setObjNewsObjects(List<NewsObjects> objNewsObjects) {
        NewsObjects.objNewsObjects = objNewsObjects;
    }

    static {
        objNewsObjects.add(new NewsObjects("https://tctechcrunch2011.files.wordpress.com/2016/08/gettyimages-584268466.jpg?w=764&amp;h=400&amp;crop=1",
                "New York Governor signs daily fantasy sports bill, DraftKings and FanDuel can operate again",
                "2016-08-04T04:20:46Z",
                "Back in June on the last day of the New York Assembly's legislative session, the state passed a bill legalizing daily fantasy sports, paving the road for the..",
                "http://social.techcrunch.com/2016/08/03/new-york-governor-signs-daily-fantasy-sports-bill-draftkings-and-fanduel-can-operate-again/"
        ));

        objNewsObjects.add(new NewsObjects("https://img.vidible.tv/prod/2016-08/03/57a274e1134aa15a39f04209_1280x720_U_v1_764_400.jpg",
                "Crunch Report | First private company to go to the Moon",
                "2016-08-04T03:00:38Z",
                "Moon Express is the first private company to get permission from the U.S. government to go to the moon, Facebook shows us its hardware lab, Tesla..",
                "http://social.techcrunch.com/2016/08/03/crunch-report-first-private-company-to-go-to-the-moon/"
        ));
        objNewsObjects.add(new NewsObjects("https://tctechcrunch2011.files.wordpress.com/2016/07/gettyimages-589718629.jpg?w=764&amp;h=400&amp;crop=1",
                "Few things are more dreadful than dealing with airline customer service. Fortunately, there’s a startup that wants to make those calls for you. For..",
                "2016-08-04T04:20:46Z",
                "Back in June on the last day of the New York Assembly's legislative session, the state passed a bill legalizing daily fantasy sports, paving the road for the..",
                "http://social.techcrunch.com/2016/08/03/airhelp-raises-12-million-to-deal-with-airline-customer-service-for-you/"
        ));

        objNewsObjects.add(new NewsObjects("https://tctechcrunch2011.files.wordpress.com/2016/08/gettyimages-584268466.jpg?w=764&amp;h=400&amp;crop=1",
                "New York Governor signs daily fantasy sports bill, DraftKings and FanDuel can operate again",
                "2016-08-04T04:20:46Z",
                "Back in June on the last day of the New York Assembly's legislative session, the state passed a bill legalizing daily fantasy sports, paving the road for the..",
                "http://social.techcrunch.com/2016/08/03/new-york-governor-signs-daily-fantasy-sports-bill-draftkings-and-fanduel-can-operate-again/"
        ));

        objNewsObjects.add(new NewsObjects("https://img.vidible.tv/prod/2016-08/03/57a274e1134aa15a39f04209_1280x720_U_v1_764_400.jpg",
                "Crunch Report | First private company to go to the Moon",
                "2016-08-04T03:00:38Z",
                "Moon Express is the first private company to get permission from the U.S. government to go to the moon, Facebook shows us its hardware lab, Tesla..",
                "http://social.techcrunch.com/2016/08/03/crunch-report-first-private-company-to-go-to-the-moon/"
        ));
        objNewsObjects.add(new NewsObjects("https://tctechcrunch2011.files.wordpress.com/2016/07/gettyimages-589718629.jpg?w=764&amp;h=400&amp;crop=1",
                "Few things are more dreadful than dealing with airline customer service. Fortunately, there’s a startup that wants to make those calls for you. For..",
                "2016-08-04T04:20:46Z",
                "Back in June on the last day of the New York Assembly's legislative session, the state passed a bill legalizing daily fantasy sports, paving the road for the..",
                "http://social.techcrunch.com/2016/08/03/airhelp-raises-12-million-to-deal-with-airline-customer-service-for-you/"
        ));

    }
}
